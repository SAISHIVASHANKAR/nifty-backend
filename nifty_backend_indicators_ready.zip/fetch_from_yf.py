# fetch_from_yf.py
print('Fetch from Yahoo Finance')