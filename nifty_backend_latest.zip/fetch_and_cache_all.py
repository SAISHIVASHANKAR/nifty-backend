# fetch_and_cache_all.py
print("Fetching EOD data and caching to nifty_stocks.db")
