# stocks.py
STOCKS = {
    "RELIANCE": "RELIANCE:NSE",
    "TCS": "TCS:NSE",
    "INFY": "INFY:NSE"
}
