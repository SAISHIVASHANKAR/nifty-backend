# fallback_bse.py
print('Fallback from BSE')