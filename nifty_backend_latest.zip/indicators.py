# indicators.py
print("Calculating indicators")
