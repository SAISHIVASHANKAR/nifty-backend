# fallback_eod.py
print('Fallback from EOD Historical')