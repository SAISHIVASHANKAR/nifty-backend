# fallback_chartink.py
print('Fallback from Chartink')